#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$ROOT_DIR/dist"
PACKAGE_NAME="code-idea-jdk17-template"
ZIP_PATH="$OUT_DIR/$PACKAGE_NAME.zip"

mkdir -p "$OUT_DIR"

TMP_DIR="$(mktemp -d)"
trap "rm -rf \"$TMP_DIR\"" EXIT

rsync -a \
  --exclude ".git" \
  --exclude "dist" \
  --exclude ".DS_Store" \
  "$ROOT_DIR/" "$TMP_DIR/$PACKAGE_NAME/"

( cd "$TMP_DIR" && zip -r "$ZIP_PATH" "$PACKAGE_NAME" >/dev/null )

echo "Template package created: $ZIP_PATH"
